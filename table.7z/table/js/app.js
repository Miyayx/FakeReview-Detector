
$(document).ready(function () {

    var curpage = 1;

    var displayPager = function () {

        $('#pages').children().remove();

        $pager = $(pagination({ cur: curpage, max: 3}));

        $pager.find('.prev-page').click(function () {
            if($(this).hasClass('disabled')) return false;
            curpage--;
            displayPager();
            return false;
        });
        $pager.find('.num-page').click(function () {
            if($(this).hasClass('active')) return false;
            curpage = parseInt($(this).text());
            displayPager();
            return false;
        });
        $pager.find('.next-page').click(function () {
            if($(this).hasClass('disabled')) return false;
            curpage++;
            displayPager();
            return false;
        });

        $pager.appendTo('#pages');

        $('#contents').children().remove();

        // Append Items to #contents here
        
        var data = [{a: 'xxx', b: 'yyy'}, {a: 1, b: 2, err: true}, {a: 'dooo', b: 'moooo~'}];
        
        data.forEach(function (d) {

            var $elem = $('<tr><td>' + d.a + '</td><td>' + d.b + '</td></tr>')

            if(d.err) $elem.addClass('error');
            $elem.appendTo('#contents');

        })

    };

    displayPager();

});
